package com.demo;

import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.model.Book;

@WebServlet("/Hello4")
public class Hello4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Book> books = Arrays.asList(new Book("121", "head first", "IT",
				"katty", 500),
				new Book("121", "head first", "IT", "katty", 500), new Book(
						"121", "head first", "IT", "katty", 500)

		);

		// List<String>
		// books=Arrays.asList("java is fun","java is too old","old is gold");
		request.setAttribute("books", books);
		RequestDispatcher rd = request.getRequestDispatcher("print2.jsp");
		rd.forward(request, response);
	}

}
