package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Hello3")
public class Hello3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		java.util.Map<String, String> foodMap = new java.util.HashMap<>();

		foodMap.put("Fruit", "Banana");
		foodMap.put("TakeAway", "Indian"); 
		foodMap.put("Drink", "Larger");
		foodMap.put("Dessert", "IceCream"); 
		foodMap.put("HotDrink", "Coffee");

		String[] foodTypes = {"Fruit", "TakeAway", "Drink", "Dessert", "HotDrink"};

		request.setAttribute("foodMap", foodMap); 
		request.setAttribute("foodTypes",foodTypes);
		
		
		/*Person person=new Person();
		Dog dog=new Dog();
		dog.setDogName("stonish");
		person.setDog(dog);
		*/
		/*String[] footballTeams = { "Liverpool", "Manchester Utd", "Arsenal", "Chelsea" };
request.setAttribute("footballList", footballTeams); 
		*/
		
		RequestDispatcher rd=request.getRequestDispatcher("show1.jsp");
		//request.setAttribute("person", person);
		rd.forward(request, response);
	}

}
