package com.demo;

import java.io.Serializable;

public class User implements Serializable {
	private static final long serialVersionUID = -3691504879401352885L;
	private String name;
	private String password;
	
	private boolean isValid;

	public boolean isValid() {

		if (name.equals(password))
			return true;
		else
			return false;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("setName is called...");
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		System.out.println("setPassword is called...");
		this.password = password;
	}

	public User(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}

	public User() {}

}
